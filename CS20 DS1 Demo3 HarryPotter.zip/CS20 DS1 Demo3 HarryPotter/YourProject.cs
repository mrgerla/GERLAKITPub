﻿using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.Collections.Generic;

namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Area for Player Variables
        

        //Runs once at the start
        public void Setup()
        {//Start of Setup
            
           
        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update

            


        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void KeyPressed()
        {
            
        }



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
