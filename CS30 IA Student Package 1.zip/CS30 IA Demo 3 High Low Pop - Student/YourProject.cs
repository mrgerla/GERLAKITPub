﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.IO;
using System.Collections.Generic;
using System;
using System.Threading.Tasks;

#endregion


namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Relative Path. Backing out of 3 folders to get into the "Main" part
        //I think that it runs out of //bin//debug//net6.0-windows
        


        //Runs once at the start
        public async void Setup()
        {//Start of Setup
            SetWindowSize(600, 600);
            Background(100);

           

            //Let File load before doing anything else
            

            //Test that it worked
            

  
            //Store Values in Appropriate Lists
                

            //List is sorted by province, not by pop
            //1. Find Max Pop
            


            //UI
            


            
            //Execute Search
            

            
            //2. Lowest Pop
            


        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update


            
            

        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            
            

        }//END of Mouse Pressed



        public void KeyPressed()
        {
            



        }//END of Key Pressed

        



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
