﻿using System.Windows;
using System.Windows.Media.Animation;
using System.Windows.Media;
using System;
using P5CSharp_Ver2;
using static P5CSharp_Ver2.GerlaKit;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace SPARKProject
{
    /// <summary>
    /// Version 2.0
    /// All Rights Reserved.
    /// Not to distrubed without written explict consent from Andrew Gerla
    /// </summary>
    public partial class MainWindow : Window
    {
        Project project;
        Storyboard storyboard;

        //ADDED for 2.9
        private Dispatcher dispatcher = Dispatcher.CurrentDispatcher; // Get the UI thread's dispatcher


        public MainWindow()
        {
            InitializeComponent();
            InitializeGerlaKit(this, canvas, consoleLogContent);

            //Set-Up Timer, Project, and Get Methods if they exist
            SetupGameTimer();
            storyboard = new Storyboard();
            project = new Project(this, canvas, storyboard, debug, consoleLogContent);

            GetMethodInfo();

            //Run Start Method if it exists
            if (_projectStartMethod != null)
            {
                       //Starting method I actually want to run
                       _projectStartMethod.Invoke(project, null);

                

                
            } 



        }


    }
}
