﻿using P5CSharp_Ver2;

namespace SPARKProject
{
    public partial class MainWindow
    {
        private System.Reflection.MethodInfo? _projectStartMethod;
        private System.Reflection.MethodInfo? _projectUpdateMethod;
        

        /// <summary>
        /// Uses Reflection to check if Method exists on Project Page
        /// </summary>
        private void GetMethodInfo()
        {
            
            _projectStartMethod = typeof(Project).GetMethod("Setup");
            _projectUpdateMethod = typeof(Project).GetMethod("Update");
        }
    }
}
