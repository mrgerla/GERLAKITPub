﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Shapes;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        public void Setup()
        {
            SetWindowSize(600, 400);
            Background(150);

        }

        public void Update()
        {
            
        }


    }
}
