﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        /// <summary>
        /// Moves shape left or right by the amount entered.
        /// </summary>
        /// <param name="shape">Enter the variable the shape is stored in.</param>
        /// <param name="changeX">Amount to move the shape left or right.</param>
        private void ChangeXBy(UIElement shape, double changeX)
        {
            double currentX = Canvas.GetLeft(shape);
            Canvas.SetLeft(shape, currentX + changeX);
        }

        /// <summary>
        /// Moves shape up and down by the amount entered.
        /// </summary>
        /// <param name="shape">Enter the variable the shape is stored in.</param>
        /// <param name="changeY">Amount to move the shape up and down.</param>
        private void ChangeYBy(UIElement shape, double changeY)
        {
            double currentY = Canvas.GetTop(shape);
            Canvas.SetLeft(shape, currentY + changeY);
        }

        /// <summary>
        /// Moves shape to the x location given.
        /// </summary>
        /// <param name="shape">Enter the variable the shape is stored in.</param>
        /// <param name="changeX">x location to move shape to.</param>
        private void SetXTo(UIElement shape, double changeX)
        {
            double currentX = Canvas.GetLeft(shape);
            if(currentX != changeX)
            {
                Canvas.SetLeft(shape, currentX + changeX);
            }
        }

        /// <summary>
        /// Moves shape to the y location given.
        /// </summary>
        /// <param name="shape">Enter the variable the shape is stored in.</param>
        /// <param name="changeY">y location to move shape to.</param>
        private void SetYTo(UIElement shape, double changeY)
        {
            double currentY = Canvas.GetTop(shape);
            if(currentY!= changeY)
            {
                Canvas.SetLeft(shape, currentY + changeY);
            }           
        }

        /// <summary>
        /// Moves to shape to a random location on the screen.
        /// </summary>
        /// <param name="shape">Enter the variable the shape is stored in.</param>
        /// <param name="maxX">Enter the width of the screen</param>
        /// <param name="maxY">Enter the height of the screen</param>
        private void GoToRandom(UIElement shape, int maxX, int maxY)
        {
            Canvas.SetLeft(shape, random.Next(maxX));
            Canvas.SetTop(shape, random.Next(maxY));
        }

        /// <summary>
        /// Shape moves to the location of the mouse.
        /// </summary>
        /// <param name="shape">Enter the variable the shape is stored in.</param>
        private void GoToMouse(UIElement shape)
        {
            double mouseYPosition = Mouse.GetPosition(window).Y;
            Canvas.SetLeft(shape, mouseYPosition);

            double mouseXPosition = Mouse.GetPosition(window).X;
                Canvas.SetLeft(shape, mouseXPosition);
        }

        /// <summary>
        /// Rotates shape by the number of degrees entered.
        /// </summary>
        /// <param name="shape">Enter the variable the shape is stored in.</param>
        /// <param name="degrees">Number of degrees to rotate</param>
        private void Turn(UIElement shape, double degrees)
        {
            double currentDegrees = 0;
            RotateTransform? currentRotation = shape.RenderTransform as RotateTransform;
            if(currentRotation != null)
            {
                currentDegrees = currentRotation.Angle;
            }
            RotateTransform rotationAmount = new RotateTransform(degrees + currentDegrees);
            shape.RenderTransformOrigin = new Point(0.5, 0.5);
            shape.RenderTransform = rotationAmount;
        }

        /// <summary>
        /// Rotatoes shape to a specific angle.
        /// </summary>
        /// <param name="shape">Enter the variable the shape is stored in.</param>
        /// <param name="degrees">Enter the degree to rotate to</param>
        private void PointTo(UIElement shape, double degrees)
        {
            RotateTransform rotationAmount = new RotateTransform(degrees);
            shape.RenderTransformOrigin = new Point(0.5, 0.5);
            shape.RenderTransform = rotationAmount;
        }





    }
}
