﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.Windows.Media.Imaging;
using System.IO;
using System.Collections.Generic;
using System;
using System.Windows.Media;

#endregion


namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        string scene = "runGame";

        Image menuButton = Image("menu.png", 10, 10, 75, 75);

        //Menu
        Rectangle backgroundMenu = Rect(100, 100, 300, 425);
        Rectangle difficultyButton = Rect(150, 150, 200, 75);
        Rectangle quitButton = Rect(150, 275, 200, 75);
        Rectangle playButton = Rect(150, 400, 200, 75);
        Text difficultyText = Text("Choose Difficulty", 155, 170);
        Text quitText = Text("Quit Game", 200, 300);
        Text playText = Text("Play", 235, 420);

        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(1000, 600);
            Background(100);

            
            //Menu
            backgroundMenu.Stroke = Stroke(255,255,255);
            backgroundMenu.StrokeWeight = 8;
            backgroundMenu.Visibility = Collapsed;

            difficultyButton.Stroke = Stroke(255,255,255);
            difficultyButton.StrokeWeight = 6;
            difficultyButton.Visibility = Collapsed;

            quitButton.Stroke = Stroke(255,255,255);
            quitButton.StrokeWeight = 6;
            quitButton.Visibility = Collapsed;
            
            playButton.Stroke = Stroke(255,255,255);
            playButton.StrokeWeight = 6;
            playButton.Visibility = Collapsed;


            difficultyText.Color = Fill(255,255,255);
            difficultyText.Size = 20;
            difficultyText.Visibility = Collapsed;

            quitText.Color = Fill(255,255,255);
            quitText.Size = 20;
            quitText.Visibility = Collapsed;

            playText.Color = Fill(255,255,255);
            playText.Size = 20;
            playText.Visibility = Collapsed;

            

        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update
            
            //Menu
            if(scene == "runGame")
            {
                //Do something

            }
            

        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            
            

        }



        public void KeyPressed()
        {
            



        }

        



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
