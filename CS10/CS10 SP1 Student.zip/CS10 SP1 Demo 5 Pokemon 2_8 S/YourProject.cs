﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.IO;
using System.Collections.Generic;
using System;

#endregion


namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE
     //Do this LAST

        //Create Global Variables









        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(400,360);
            Background("evolutionTemplate.jpg");

            //Draw Rectangle
            



            
            //Hide Rectangle
            



            //Change Text

            




            //Draw Images
            




            //Change Evo2 Transparency
            





        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update


            
            

        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {

            //Change Opacity
            



            
            //Advanced!!! Don't need to be able to do this




        } // End of Mouse Pressed



        public void KeyPressed()
        {

            //Reset






        } // End of Key Pressed

        



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
