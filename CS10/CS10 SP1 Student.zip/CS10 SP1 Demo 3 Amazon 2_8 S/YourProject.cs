﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.IO;
using System.Collections.Generic;
using System;

#endregion


namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Product 1 Variables





        //Product 2





        //Product 3





        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(1079, 550);
            Background(100);

            Image("shoes.png", 0, 0, 1079, 550);

            //Changing Text Properties
            


            //Product 1
            



            //Product 2
           




            //Product 3
            




        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update


            
            

        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            PrintMouseLocation();   
            

        }//End of Mouse Pressed



        public void KeyPressed()
        {
                       
            

            

        }//end of Key Pressed

        



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
