﻿using System.Windows;
using System.Windows.Media.Animation;

namespace P5CSharp_Ver2
{
    /// <summary>
    /// Version 1.0
    /// All Rights Reserved.
    /// Not to distrubed without written explict consent from Andrew Gerla
    /// </summary>
    public partial class MainWindow : Window
    {
        Project project;
        Storyboard storyboard;
        
        public MainWindow()
        {
            InitializeComponent();
            
            //Set-Up Timer, Project, and Get Methods if they exist
            SetupGameTimer();
            storyboard = new Storyboard();
            project = new Project(this, this, canvas, storyboard, debug, consoleLogContent);

            GetMethodInfo();

            //Run Start Method if it exists
            if (_projectStartMethod != null) _projectStartMethod.Invoke(project, null);         
            
        }
    }
}
