﻿using System.Windows.Media;
using System.Windows.Shapes;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        /// <summary>
        /// Draws a triangle based on 3 Points.
        /// Returns a triangle.
        /// </summary>
        /// <param name="name">Enter name.</param>
        /// <param name="point1X">Point 1's x coordinate</param>
        /// <param name="point1Y">Point 1's y coordinate</param>
        /// <param name="point2X">Point 2's x coordinate</param>
        /// <param name="point2Y">Point 2's y coordinate</param>
        /// <param name="point3X">Point 3's x coordinate</param>
        /// <param name="point3Y">Point 3's y coordinate</param>
        /// <returns>A Polygon. Save to a variable to modify afterwards.</returns>
        public Polygon Triangle(double point1X, double point1Y, double point2X, double point2Y, double point3X, double point3Y)
        {
            Polygon triangle = new Polygon();
            System.Windows.Point Point1 = new System.Windows.Point(point1X, point1Y);
            System.Windows.Point Point2 = new System.Windows.Point(point2X, point2Y);
            System.Windows.Point Point3 = new System.Windows.Point(point3X, point3Y);
            PointCollection trianglePoints = new PointCollection();
            trianglePoints.Add(Point1);
            trianglePoints.Add(Point2);
            trianglePoints.Add(Point3);
            triangle.Points = trianglePoints;
            triangle.Stroke = strokeColor;
            triangle.Fill = fillColor;
            triangle.StrokeThickness = strokeWeight;
            
            
            if (canvas != null) { canvas.Children.Add(triangle); }
            return triangle;

        }
    }
}
