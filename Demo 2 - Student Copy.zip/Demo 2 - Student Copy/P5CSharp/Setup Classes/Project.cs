﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        private static MainWindow? mainWindow;
        private static Window? window;
        private static Canvas? canvas; 
        Random random;
        private static Storyboard? storyboard;
        private static ScrollViewer? consoleLog;
        private static Label? consoleContent;
        


        public Project(MainWindow main, Window? mainWindow, Canvas? mainCanvas, Storyboard? story, ScrollViewer? debug, Label _consoleCont)
        {
            consoleContent = _consoleCont;
            mainWindow= main;
            window = mainWindow;
            canvas = mainCanvas;
            storyboard = story;
            consoleLog = debug;
            random = new Random();
            //Setup Mouse and Key Pressed Events, Methods
            GetEventMethodInfo();
            mainWindow.MouseDown += mousePressedSubscriber;
            mainWindow.KeyDown += keyPressedSubscriber;
        }


    }
}
