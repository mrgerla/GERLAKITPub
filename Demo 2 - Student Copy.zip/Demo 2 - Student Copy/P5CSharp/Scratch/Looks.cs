﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        /// <summary>
        /// Makes an object visible.
        /// </summary>
        /// <param name="shape">Enter variable shape is stored in.</param>
        private void Show(UIElement shape)
        {
            shape.Visibility = Visibility.Visible;
        }

        /// <summary>
        /// Makes an object NOT visible.
        /// </summary>
        /// <param name="shape">Enter variable shape is stored in.</param>
        private void Hide(UIElement shape)
        {
            shape.Visibility = Visibility.Collapsed;
        }


    }
}
