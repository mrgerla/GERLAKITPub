﻿using System.Windows;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        //private void IfOnEdgeBounce(UIElement shape)
        //{
        //    var windowHeight = window.ActualHeight;
        //    var windowWidth = window.ActualWidth;
        //    //var shapeX =
        //}

        /// <summary>
        /// Determines if mouse has clicked sprite.
        /// Should ONLY be used in MOUSEPRESSED FUNCTION
        /// </summary>
        /// <param name="shape">Variable that sprite is stored in.</param>
        private bool SpriteClicked(UIElement shape)
        {
            if (shape.IsMouseDirectlyOver)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        //private bool Touching(UIElement shape, UIElement otherShape)
        //{
            //Point point = shape.TranslatePoint(new Point(0,0), otherShape);
            //return otherShape.InputHitTest(point) != null;
            //Only works on one side, also it seems to really slow down the program
            //Threading maybe needed to make this method work




            //Rect rect1 = new Rect(
            //Rect rect2 = new Rect(otherShape.RenderSize);
            //Debug.WriteLine(rect1.IntersectsWith(rect2));
            //return rect1.IntersectsWith(rect2);
        //}
    }
}
