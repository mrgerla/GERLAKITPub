﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Shapes;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        //Area for Player Variables
        Rectangle player;
        Label winWords;
        Rectangle obstacle;



        public void Setup()
        {
            SetWindowSize(600, 600); //DO NOT CHANGE OR DELETE
            Background(150);

            //Player Code Area
            player = Rect(300, 20, 50,50);
            obstacle = Rect(300, 400, 50,50);

            //Text
            winWords = Text("Not hitting Obstacle", 100, 400);




        }//END of SETUP

        public void Update()
        {
        //Player Update
            if(IsKeyDown(Key.A) == true)
            {
                ChangeXBy(player, -5);
            }


            if (IsKeyDown(Key.S) == true)
            {
                ChangeYBy(player, 5);
            }

            if (CheckCollision(player, obstacle) == true)
            {
                
                winWords.Content = "Hitting Obstacles";
            }




        }//END OF UPDATE




    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
