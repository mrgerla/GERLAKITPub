﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace SPARKProject
{
    public partial class Project
    {
        
        public static Window? window;
        public static Canvas? canvas; 
        public static Random random;
        private static Storyboard? storyboard;
        private static ScrollViewer? consoleLog;
        public static Label? consoleContent;
        


        public Project(Window? mainWindow, Canvas? mainCanvas, Storyboard? story, ScrollViewer? debug, Label _consoleCont)
        {
            consoleContent = _consoleCont;
            window = mainWindow;
            canvas = mainCanvas;
            storyboard = story;
            consoleLog = debug;
            random = new Random();
            //Setup Mouse and Key Pressed Events, Methods
            GetEventMethodInfo();
            mainWindow.MouseDown += mousePressedSubscriber;
            mainWindow.KeyDown += keyPressedSubscriber;
        }


    }
}
