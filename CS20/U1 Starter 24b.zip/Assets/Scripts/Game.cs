using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Game
{

    public static int Score = 0;
    public static float Time = 30;


}
