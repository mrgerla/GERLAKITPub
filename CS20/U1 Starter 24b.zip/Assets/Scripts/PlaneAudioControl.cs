using UnityEngine;

public class PlaneAudioControl : MonoBehaviour
{
    AudioSource engineAudio;
    AudioLowPassFilter lowPassFilter;
    AudioDistortionFilter distortionFilter;

    //Panning
    public float panSpeed = 1.0f; // Adjust to control how quickly the pan changes
    public float panMax = 0.5f;

    //Pitch and Volume Change
    public float basePitch = 1.0f; // Default pitch
    public float minPitch = 0.97f;
    public float maxPitch = 1.03f;

    public float baseVolume = 1.0f; // Default volume
    public float minVolume = 0.990f;
    public float maxVolume = 1.01f;


    public float maxChangeInterval = 2.0f;
    public float minChangeInterval = 1.0f;

    private float nextChangeTime;


    // Low-Pass Filter Settings
    public float maxCutoffFrequency = 22000f; // No filtering
    public float minCutoffFrequency = 500f;  // Heavy filtering
    public float filterSmoothSpeed = 1.0f;   // Speed of transition

    // Distortion Filter Settings
    public float maxDistortion = 0.5f; // Max distortion level for strain
    public float minDistortion = 0.0f; // No distortion (default)


    void Start()
    {
        engineAudio = GetComponent<AudioSource>();
        lowPassFilter = GetComponent<AudioLowPassFilter>();
        distortionFilter = GetComponent<AudioDistortionFilter>();
    }

    void Update()
    {
        //Panning Audio
        float horizontalInput = Input.GetAxis("Horizontal");
        float targetPan = Mathf.Lerp(engineAudio.panStereo, horizontalInput, Time.deltaTime * panSpeed);
        engineAudio.panStereo = Mathf.Clamp(targetPan, -panMax, panMax);

        //Pitch and Volume
        if (Time.time >= nextChangeTime)
        {
            engineAudio.pitch = Random.Range(minPitch, maxPitch);
            engineAudio.volume = Random.Range(minVolume, maxVolume);
            nextChangeTime = Time.time + Random.Range(minChangeInterval,maxChangeInterval);
        }



        // Dynamic Adjustments Based on Vertical Input
        float verticalInput = Input.GetAxis("Vertical");



        // Adjust Pitch for Strain
        float targetPitch = basePitch + verticalInput * (verticalInput > 0 ? 0.05f : 0.02f); // More pitch variation for upward input
        engineAudio.pitch = Mathf.Lerp(engineAudio.pitch, targetPitch, Time.deltaTime * filterSmoothSpeed);

        // Adjust Volume for Power Loss
        float targetVolume = Mathf.Lerp(baseVolume, maxVolume, (verticalInput + 1) / 2); // Boost volume for upward input
        engineAudio.volume = Mathf.Lerp(engineAudio.volume, targetVolume, Time.deltaTime * filterSmoothSpeed);

        // Adjust Low-Pass Filter for Strain Effect
        float targetCutoff = Mathf.Lerp(minCutoffFrequency, maxCutoffFrequency, (verticalInput + 1) / 2); // Map -1 to 1 input to cutoff range
        lowPassFilter.cutoffFrequency = Mathf.Lerp(lowPassFilter.cutoffFrequency, targetCutoff, Time.deltaTime * filterSmoothSpeed);


        // Adjust Distortion for Engine Strain
        float targetDistortion = Mathf.Lerp(minDistortion, maxDistortion, Mathf.Abs(verticalInput)); // More distortion as input moves away from 0
        distortionFilter.distortionLevel = Mathf.Lerp(distortionFilter.distortionLevel, targetDistortion, Time.deltaTime * filterSmoothSpeed);
    }
}
    

