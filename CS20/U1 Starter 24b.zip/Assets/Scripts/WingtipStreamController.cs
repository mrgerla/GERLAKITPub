using UnityEngine;

[RequireComponent(typeof(ParticleSystem))]
public class WingtipStreamController : MonoBehaviour
{
    [Header("Stream Settings")]
    [Tooltip("The color of the stream (applies to the Particle System's Start Color).")]
    public Color streamColor = Color.white;

    [Tooltip("The lifespan of each particle in the stream (in seconds).")]
    [Range(0.1f, 10f)]
    public float particleLifespan = 5f;

    [Tooltip("The base emission rate of particles when there is no horizontal input.")]
    [Range(0, 300)]
    public float baseEmissionRate = 0f;

    [Tooltip("The maximum additional particles per second added by horizontal input.")]
    [Range(0, 300)]
    public float maxEmissionRate = 150f;
    public float EmissionRamp = 5f;

    private ParticleSystem particle;
    private ParticleSystem.MainModule mainModule;
    private ParticleSystem.EmissionModule emissionModule;
    private float currentEmissionRate = 0f;

    public enum SmokeDirection
    {
        Both,       // Smoke appears on both left and right turns
        LeftOnly,   // Smoke appears only on left turns
        RightOnly   // Smoke appears only on right turns
    }

    [Header("Stream Behavior")]
    [Tooltip("Select when the smoke should appear (on left turns, right turns, or both).")]
    public SmokeDirection horizontalMovement = SmokeDirection.Both;


    void Start()
    {
        // Get the Particle System and its modules
        particle = GetComponent<ParticleSystem>();
        mainModule = particle.main;
        emissionModule = particle.emission;

        // Apply initial settings
        UpdateParticleSettings();
    }

    void Update()
    {
        // Get horizontal input
        float horizontalInput = Input.GetAxis("Horizontal");

        // Determine if the smoke should be active based on the selected direction
        bool showSmoke = false;
        switch (horizontalMovement)
        {
            case SmokeDirection.Both:
                showSmoke = Mathf.Abs(horizontalInput) > 0;
                break;
            case SmokeDirection.LeftOnly:
                showSmoke = horizontalInput < 0;
                break;
            case SmokeDirection.RightOnly:
                showSmoke = horizontalInput > 0;
                break;
        }

        // Target emission rate based on input
        float targetEmissionRate = showSmoke
            ? baseEmissionRate + Mathf.Abs(horizontalInput) * maxEmissionRate
            : 0f;

        // Smoothly interpolate the current emission rate toward the target
        currentEmissionRate = Mathf.Lerp(currentEmissionRate, targetEmissionRate, Time.deltaTime * EmissionRamp);

        // Update the emission rate
        var rateOverTime = emissionModule.rateOverTime;
        rateOverTime.constant = currentEmissionRate;
        emissionModule.rateOverTime = rateOverTime;
    }

    /// <summary>
    /// Updates the particle system's color and lifespan.
    /// </summary>
    public void UpdateParticleSettings()
    {
        // Update particle color
        mainModule.startColor = streamColor;

        // Update particle lifespan
        mainModule.startLifetime = particleLifespan;
    }
}