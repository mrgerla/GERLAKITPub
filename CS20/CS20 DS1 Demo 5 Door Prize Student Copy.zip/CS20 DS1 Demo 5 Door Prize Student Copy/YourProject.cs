﻿using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.Windows.Media.Imaging;
using System.IO;
using System.Collections.Generic;

namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Area for Player Variables

        //Take in Information
        Text enterName = new Text("Enter Name", 10, 500);
        Text enterAvatar = new Text("Enter Avatar", 10, 550);

        Rectangle addButton = new Rectangle (350, 550, 100,50);
        Text addButtonText = new Text("Add", 360, 560);


        //Random Winner
        




        
        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(800, 600);
            Background("castle.jpg");

            enterName.Color = Fill(255, 255, 255);
            enterName.Size = 30;

            enterAvatar.Color = Fill(255, 255, 255);
            enterAvatar.Size = 30;
            
            addButton.Fill = Fill(255, 255, 255);
            addButtonText.Size = 30;

            
            Print("Press Enter to when you are done");
            Print("If you Dare");
            Print("Add your name to list...");
            Print("Winner gets to stay in this Completely Normal Castle");

            
        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update



        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            
            

        }



        public void KeyPressed()
        {
            



        }


    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
