﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.IO;
using System.Collections.Generic;
using System;

#endregion


namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE
        Image winnerPic = new Image("touchdown.jpg_large", 0, 0, 1000, 600);
        Image kelce = new Image("kelce.png", 400,20,50,75);
        List<Image> eagles = new List<Image>();    


        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(1000, 600);
            Background("field.jpg");

            //Create Blockers






            //STARTING CODE, DO NOT DELETE
            winnerPic.X = 3000;
            winnerPic.Y = 3000;
            winnerPic.Visibility = Collapsed;


            

        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update

            //Move Blockers


            //Change Move Direction


            //Move Blockers






            //STARTING CODE, DO NOT DELETE
            //Move Kelce
            if (IsKeyDown(Key.Up))
            {
                kelce.Y -= 5;
            }

            if (IsKeyDown(Key.Down))
            {
                kelce.Y += 5;
            }

            if (IsKeyDown(Key.Right))
            {
                kelce.X += 5;
            }

            if (IsKeyDown(Key.Left))
            {
                kelce.X -= 5;
            }

            //Collision detection
            for(int i =0; i < eagles.Count; i++)
            {
                if(CheckCollision(kelce, eagles[i]))
                {
                    kelce.X = 400;
                    kelce.Y = 20;
                } 
            }

            //Winning
            if(kelce.Y > 500)
            {
                winnerPic.Y = 0;
                winnerPic.X = 0;
                winnerPic.Visibility = Visible;
                
            }



        }//END OF UPDATE


     

    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
