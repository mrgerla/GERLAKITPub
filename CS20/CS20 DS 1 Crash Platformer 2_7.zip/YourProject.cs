﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.IO;
using System.Collections.Generic;
using System;

#endregion


namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Floor and Platforms
        List<Image> Floor = new List<Image>();
        List<Image> PlatForms = new List<Image>();

        //Crash Bandicoot
        Image player = new Image("runR1.png", 250, 300, 80, 80);


        //Fruit
        List<Image> Fruit = new List<Image>();

        //Crystal
        Image Crystal = new Image("crystal.png", 1300, 250, 25, 75);


        //Score
        int fruitCount = 0;
        Text fruitCountText = new Text(0, 50, 50);



        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(600, 600);
            Background(100);

            //Creating New Floors, adding to List
            Floor.Add(  new Image("crashFloor.png", 200, 500, 200, 100)   );


            //Creating Platforms
            PlatForms.Add(new Image("crashPlat.png", 400, 350, 200, 50));
            PlatForms.Add(new Image("crashPlat.png", 800, 350, 200, 50));
            PlatForms.Add(new Image("crashPlat.png", 1200, 350, 200, 50));

            //Creating Fruit
            Fruit.Add(new Image("fruit.png", 440, 290, 50, 50));
            Fruit.Add(new Image("fruit.png", 500, 290, 50, 50));
            Fruit.Add(new Image("fruit.png", 560, 290, 50, 50));
            Fruit.Add(new Image("fruit.png", 840, 290, 50, 50));
            Fruit.Add(new Image("fruit.png", 900, 290, 50, 50));
            Fruit.Add(new Image("fruit.png", 9060, 290, 50, 50));


            //Score
            fruitCountText.Size = 40;
            fruitCountText.Color = Fill(255, 255, 255);


        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update

            //UPDATE FLOOR, FRUIT AND CRYSTAL





            //JUMPING, COLLISION AND FALLING
            

            
            

        }//END OF UPDATE

      
    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
