﻿using System.Diagnostics;
using System.Windows.Input;

namespace SPARKProject
{
    public partial class Project
    {
        //Mouse
        private static double MouseX;
        private static double MouseY;
        System.Reflection.MethodInfo? _mousePressedMethodInfo;

        //Key
        private  Key key;
        System.Reflection.MethodInfo? _keyPressedMethodInfo;

        //Key without D before the numbers
        private string KeyValue = "None";


        private void GetEventMethodInfo()
        {
            _mousePressedMethodInfo = typeof(Project).GetMethod("MousePressed");
            _keyPressedMethodInfo = typeof(Project).GetMethod("KeyPressed");
        }

        private void mousePressedSubscriber(object sender, MouseButtonEventArgs e)
        {
            //MouseX = e.GetPosition(window).X;
            //MouseY = e.GetPosition(window).Y;
            if (_mousePressedMethodInfo != null) _mousePressedMethodInfo.Invoke(this, null);
        }

        public static void UpdateMousePositions()
        {
            MouseX = Mouse.GetPosition(window).X;
            MouseY = Mouse.GetPosition(window).Y;
        }


        private void keyPressedSubscriber(object sender, KeyEventArgs e)
        {

            key = e.Key;
            //Get rid of D for KeyValue
            string stringKey = key.ToString();
            if (key >= Key.D0 && key <= Key.D9)
            {
                KeyValue = stringKey.Substring(1);
            }
            else if (key >= Key.NumPad0 && key <= Key.NumPad9)
            {
                KeyValue = stringKey.Substring(6);
            }
            else
            {
                KeyValue = stringKey;
            }

            if (_keyPressedMethodInfo != null) _keyPressedMethodInfo.Invoke(this, null);
            ModifierKeysConverter converter = new ModifierKeysConverter();
            
        }

        /// <summary>
        /// Determines if a key is currently pressed.
        /// Will return true or false.
        /// </summary>
        /// <param name="key">Enter the key as Key.___</param>
        /// <returns></returns>
        private bool IsKeyDown(Key key)
        {
            if (Keyboard.IsKeyDown(key))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
