﻿using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.Collections.Generic;

namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Area for Player Variables
        //Floor
        

        //Crash
        Image player = new Image("idle.png", 250, 300, 80, 80);




        //Fruit
        


        //Crystal
        


        //Score
        int fruitCount = 0;
        Text fruitCountText = new Text(0, 50, 50);


        //All of you Shapes should be created here
        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(600, 600);
            Background(100);




            //Platforms
            



            //Fruit
            




            //Crystal
            


            //Score
            fruitCountText.Size = 40;
            fruitCountText.Color = Fill(255, 255, 255);

        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update

            //Crash Changes
            






            //Check Collisions
            







            //Jumping
           






            //UpdateFloor
            






            //UpdatePlatforms
            








            //Update Fruit
            







            //Check if Collected Fruit
            








            //Update Crystal
            







            //Check Crystal Collision
            






            //Update Crash on Screen - Must be Last
            






        }//END OF UPDATE


    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
