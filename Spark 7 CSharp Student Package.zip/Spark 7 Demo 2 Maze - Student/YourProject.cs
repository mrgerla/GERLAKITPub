﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.IO;
using System.Collections.Generic;
using System;

#endregion


namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Player


        //Finish Line


        //Maze Walls - Mr.Gerla's Grade 11 Code
        List<CustomShape> allRectangles= new List<CustomShape>();

        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(600, 600);
            Background(230);

            //Player
            



            //Finish Line
            
            



            //Maze Walls - Mr.Gerla's Grade 11 Code
            Fill(219, 18, 199);
            Stroke(219, 18, 199);
            allRectangles.Add(Rect(100, 0, 25, 500));
            allRectangles.Add(Rect(200, 100, 25, 500));
            allRectangles.Add(Rect(300, 0, 25, 500));
            allRectangles.Add(Rect(400, 100, 25, 500));
            allRectangles.Add(Rect(500, 0, 25, 500));


            

        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update

            //Move Player
            
            


            //Collision with Wall



            
            //Check Collision with Finish Line



            

        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            
            

        }



        public void KeyPressed()
        {
            



        }

        



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
