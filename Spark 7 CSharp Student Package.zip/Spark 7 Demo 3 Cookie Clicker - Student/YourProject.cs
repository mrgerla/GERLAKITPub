﻿using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;

namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Images



        //Score


               


        //All of you Shapes should be created here
        //Runs once at the start
        public void Setup()
        {//Start of Setup
            
            //Window
            SetWindowSize(600, 600);
            Background(220);


            //Cookie Image

            


            //Mouse Picture



            //Score Text

            

        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update
        


            //Picture Follows Mouse

            


        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            //If Mouse is Over Cookie when Clicking
            


        }//END OF MOUSE PRESSED



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
