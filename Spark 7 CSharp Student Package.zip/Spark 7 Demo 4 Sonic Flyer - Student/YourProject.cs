﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.IO;
using System.Collections.Generic;
using System;

#endregion


namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Images
        Image ground1;
        Image ground2;
        Image tails;
        Image ring;

        //UI
        int score = 0;
        Text scoreWords;
        double time = 0;
        Text timeText;

        //Runs once at the start
        public void Setup()
        {//Start of Setup
            
            //Window
            SetWindowSize(600, 600);
            Background(0);


            //UI



            //Ring
            ring = Image("ring.webp", 300, 300, 40, 40);

            //Player
            tails = Image("tails.webp", 40, 100, 75, 75);


            //Ground
            ground1 = Image("ground.png", 100, 400, 600, 400);




        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update

            // //Looping Ground

            //Move Ground
            



            //Loop Ground
            





            //Move Tails
           




            // //Rings

            //Move Ring
            



            //Loop Ring
            





            //Get Ring
            




            //Track Time
           




        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            
            

        }//END of Mouse Pressed



        public void KeyPressed()
        {
            



        }//END of Key Pressed

        



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
