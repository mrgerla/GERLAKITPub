﻿using System;
using System.Collections.Generic;
using System.Windows.Media.Imaging;
using static P5CSharp_Ver2.GerlaKit;
using P5CSharp_Ver2;

namespace SPARKProject
{
    public partial class Project
    {
        List<Image>? carObstacles = new List<Image>();
        List<int> speed = new List<int>();
        Image obstacle1;
        Image obstacle2;
        Image obstacle3;
        Image obstacle4;
        BitmapImage rightLambo;
        BitmapImage leftLambo;

        void CreateObstacles()
        {
            obstacle1 = Image("lambo.png", RandomNumber(50, 500), 100, 70, 30);
            obstacle2 = Image("lambo.png", RandomNumber(50, 500), 200, 70, 30);
            obstacle3 = Image("lambo.png", RandomNumber(50, 500), 300, 70, 30);
            obstacle4 = Image("lambo.png", RandomNumber(50, 500), 400, 70, 30);
            rightLambo = new BitmapImage(new Uri($"..\\..\\..\\Images\\lambo.png", UriKind.Relative));
            leftLambo = new BitmapImage(new Uri($"..\\..\\..\\Images\\llambo.png", UriKind.Relative));

            carObstacles.Add(obstacle1);
            carObstacles.Add(obstacle2);
            carObstacles.Add(obstacle3);
            carObstacles.Add(obstacle4);

            foreach (Image obstacle in carObstacles)
            {

                int possibleSpeed = RandomNumber(2, 5);
                int posNeg = RandomNumber(0, 1);
                if (posNeg == 0)
                {
                    speed.Add(possibleSpeed);
                    obstacle.Source = rightLambo;

                }
                else
                {
                    speed.Add(possibleSpeed * -1);
                    obstacle.Source = leftLambo;
                }

            }

        }

        void CreateObstacles(string userImage)
        {
            obstacle1 = Image(userImage, RandomNumber(50, 500), 100, 70, 30);
            obstacle2 = Image(userImage, RandomNumber(50, 500), 200, 70, 30);
            obstacle3 = Image(userImage, RandomNumber(50, 500), 300, 70, 30);
            obstacle4 = Image(userImage, RandomNumber(50, 500), 400, 70, 30);
            rightLambo = new BitmapImage(new Uri($"..\\..\\..\\Images\\{userImage}", UriKind.Relative));
            leftLambo = new BitmapImage(new Uri($"..\\..\\..\\Images\\{userImage}", UriKind.Relative));

            carObstacles.Add(obstacle1);
            carObstacles.Add(obstacle2);
            carObstacles.Add(obstacle3);
            carObstacles.Add(obstacle4);

            foreach (Image obstacle in carObstacles)
            {

                int possibleSpeed = RandomNumber(2, 5);
                int posNeg = RandomNumber(0, 1);
                if (posNeg == 0)
                {
                    speed.Add(possibleSpeed);
                    obstacle.Source = rightLambo;

                }
                else
                {
                    speed.Add(possibleSpeed * -1);
                    obstacle.Source = leftLambo;
                }

            }

        }

        void CreateObstacles(string leftImage, string rightImage)
        {
            obstacle1 = Image(leftImage, RandomNumber(50, 500), 100, 70, 30);
            obstacle2 = Image(leftImage, RandomNumber(50, 500), 200, 70, 30);
            obstacle3 = Image(leftImage, RandomNumber(50, 500), 300, 70, 30);
            obstacle4 = Image(leftImage, RandomNumber(50, 500), 400, 70, 30);
            rightLambo = new BitmapImage(new Uri($"..\\..\\..\\Images\\{rightImage}", UriKind.Relative));
            leftLambo = new BitmapImage(new Uri($"..\\..\\..\\Images\\{leftImage}", UriKind.Relative));

            carObstacles.Add(obstacle1);
            carObstacles.Add(obstacle2);
            carObstacles.Add(obstacle3);
            carObstacles.Add(obstacle4);

            foreach (Image obstacle in carObstacles)
            {

                int possibleSpeed = RandomNumber(2, 5);
                int posNeg = RandomNumber(0, 1);
                if (posNeg == 0)
                {
                    speed.Add(possibleSpeed);
                    obstacle.Source = rightLambo;

                }
                else
                {
                    speed.Add(possibleSpeed * -1);
                    obstacle.Source = leftLambo;
                }

            }

        }


        void CreateObstacles(string leftImage, string rightImage, int minSpeed, int maxSpeed)
        {
            obstacle1 = Image(leftImage, RandomNumber(50, 500), 100, 70, 30);
            obstacle2 = Image(leftImage, RandomNumber(50, 500), 200, 70, 30);
            obstacle3 = Image(leftImage, RandomNumber(50, 500), 300, 70, 30);
            obstacle4 = Image(leftImage, RandomNumber(50, 500), 400, 70, 30);
            rightLambo = new BitmapImage(new Uri($"..\\..\\..\\Images\\{rightImage}", UriKind.Relative));
            leftLambo = new BitmapImage(new Uri($"..\\..\\..\\Images\\{leftImage}", UriKind.Relative));

            carObstacles.Add(obstacle1);
            carObstacles.Add(obstacle2);
            carObstacles.Add(obstacle3);
            carObstacles.Add(obstacle4);

            foreach (Image obstacle in carObstacles)
            {

                int possibleSpeed = RandomNumber(minSpeed, maxSpeed);
                int posNeg = RandomNumber(0, 1);
                if (posNeg == 0)
                {
                    speed.Add(possibleSpeed);
                    obstacle.Source = rightLambo;

                }
                else
                {
                    speed.Add(possibleSpeed * -1);
                    obstacle.Source = leftLambo;
                }

            }

        }

        void UpdateObstacles()
        {
            for (int i = 0; i < carObstacles.Count; i++)
            {
                carObstacles[i].X += speed[i];
                                                
                if (carObstacles[i].X > 550 || carObstacles[i].X < 0)
                {
                    speed[i] = speed[i] * -1;

                    if(speed[i] < 0)
                    {
                        carObstacles[i].Source = leftLambo;
                    }
                    else
                    {
                        carObstacles[i].Source = rightLambo;
                    }
                }

            }

        }



    }
}
