﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.IO;
using System.Collections.Generic;
using System;

#endregion


namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Area for Variables to Store Costumes, Locations ect.

        //READ: carObstacles   is the variable that holds ALL of the car pictures. Use it for checking the collisions

        //Player
        Rectangle player;


        //Runs once at the start
        public void Setup()
        {//Start of Setup


            SetWindowSize(600, 600); //DO NOT CHANGE OR DELETE
            Background(150);
            //               left pic      right pic    min speed   max speed
            CreateObstacles("llambo.png", "rlambo.png",   2,         5); //DO NOT DELETE, CAN Change Pictures and speed

            
            //Player Code Area

            

        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update

            //Moves and Updates Obstacles
            UpdateObstacles();
            
            

        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            
            

        }//END OF MOUSE PRESSED



        public void KeyPressed()
        {




        }//END OF KEY PRESSED





    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
