﻿using System.Windows;
using System.Windows.Controls;

namespace P5CSharp_Ver2
{
    public partial class Project
    {

        /// <summary>
        /// Writes text on canvas.
        /// </summary>
        /// <param name="textToWrite">Write text in "".</param>
        /// <param name="xCoordinate">x coordinate of left side of text</param>
        /// <param name="yCoordinate">y coordinate of right side of text</param>
        /// <returns>Text. Save to a variable to modify afterwards.</returns>
        public Label Text(object textToWrite, double xCoordinate, double yCoordinate)
        {
            Label label = new Label();
            label.Content = textToWrite;
            label.Foreground = strokeColor;
            label.Visibility = Visibility.Visible;
            label.FontFamily = _font;
            label.FontSize = _textSize;

            Canvas.SetLeft(label, xCoordinate);
            Canvas.SetTop(label, yCoordinate);



            if (canvas != null) canvas.Children.Add(label);

            return label;
        }

    }
}
