﻿using System;
using System.Diagnostics;
using System.Windows.Threading;

namespace P5CSharp_Ver2
{
    public partial class MainWindow
    {
        private Stopwatch programRunTime = Stopwatch.StartNew(); 
        
        /// <summary>
        /// Sets up a timer to run update loop.
        /// </summary>
        private void SetupGameTimer()
        {
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(1000 / 60);
            timer.Tick += UpdateData;
            timer.Start();
        }

        private void UpdateData(object? sender, EventArgs e)
            {
                if(_projectUpdateMethod != null) _projectUpdateMethod.Invoke(project, null);
                project.UpdateDeltaTime(programRunTime.ElapsedMilliseconds);
                canvas.InvalidateVisual(); //Forces UI to redraw. This is locking Data to FPS
            }    
    }
}

//This is supposed to start a new thread. It is not working, so... for now use the same thread as the UI
//private void setupGameTimer()
//{
//    Task.Factory.StartNew(() =>
//    {
//        DispatcherTimer timer = new DispatcherTimer();
//        timer.Interval = TimeSpan.FromMilliseconds(1000 / 60);
//        timer.Tick += updateData;
//        timer.Start();

//    });
//}
