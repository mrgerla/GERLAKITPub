﻿namespace P5CSharp_Ver2
{
    public partial class Project
    {
            private double deltaTime;
            private double _previousFrameTime = 0;

            internal void UpdateDeltaTime(double timeProgramRunning)
            {
                deltaTime = timeProgramRunning - _previousFrameTime;
                _previousFrameTime = timeProgramRunning;
            }
    }
}
