﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        private void UpdateX(UIElement shape, double xLocation)
        {
            Canvas.SetLeft(shape, xLocation);
        }


        private void UpdateY(UIElement shape, double yLocation)
        {
            Canvas.SetTop(shape, yLocation);
        }

        private void UpdateXY(UIElement shape, double xLocation, double yLocation)
        {
            Canvas.SetLeft(shape, xLocation);
            Canvas.SetTop(shape, yLocation);
        }
    }
}
