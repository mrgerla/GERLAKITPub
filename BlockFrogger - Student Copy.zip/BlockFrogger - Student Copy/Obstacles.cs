﻿using System;
using System.Collections.Generic;
using System.Windows.Shapes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        List<Rectangle>? rectObstacles = new List<Rectangle>();
        List<int> speed = new List<int>();
        Rectangle obstacle1;
        Rectangle obstacle2;
        Rectangle obstacle3;
        Rectangle obstacle4;

        void CreateObstacles()
        {
            obstacle1 = Rect(RandomNumber(50, 500), 100, 50, 50);
            obstacle2 = Rect(RandomNumber(50, 500), 200, 50, 50);
            obstacle3 = Rect(RandomNumber(50, 500), 300, 50, 50);
            obstacle4 = Rect(RandomNumber(50, 500), 400, 50, 50);

            rectObstacles.Add(obstacle1);
            rectObstacles.Add(obstacle2);
            rectObstacles.Add(obstacle3);
            rectObstacles.Add(obstacle4);

            foreach (Rectangle obstacle in rectObstacles)
            {

                int possibleSpeed = RandomNumber(2, 5);
                int posNeg = RandomNumber(0, 1);
                if (posNeg == 0)
                {
                    speed.Add(possibleSpeed);
                }
                else
                {
                    speed.Add(possibleSpeed * -1);
                }

            }

        }

        void UpdateObstacles()
        {
            for (int i = 0; i < rectObstacles.Count; i++)
            {
                ChangeXBy(rectObstacles[i], speed[i]);

                double currentLocation = Canvas.GetLeft(rectObstacles[i]);
                if (currentLocation > 550 || currentLocation < 0)
                {
                    speed[i] = speed[i] * -1;
                }

            }

        }



    }
}
