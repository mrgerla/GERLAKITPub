﻿using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows;
using System.Diagnostics;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        bool CheckCollision(UIElement player, Image obstacles)
        {
            double currentXPosition = Canvas.GetLeft(player);
            double currentYPosition = Canvas.GetTop(player);

            double obstacleX = Canvas.GetLeft(obstacles);
            double obstacleY = Canvas.GetTop(obstacles);

            
            if ((currentXPosition >= obstacleX && currentXPosition <= obstacleX + obstacles.Width) || (currentXPosition + obstacles.Width >= obstacleX && currentXPosition + obstacles.Width <= obstacleX + obstacles.Width))
            {
                
                if ((currentYPosition >= obstacleY && currentYPosition <= obstacleY + obstacles.Height) || (currentYPosition + obstacles.Height >= obstacleY && currentYPosition + obstacles.Height <= obstacleY + obstacles.Height))
                {
                    
                    return true;
                }
            }

            return false;
        }




        bool CheckCollision(UIElement player, List<Image> obstacles)
        {
            double currentXPosition = Canvas.GetLeft(player);
            double currentYPosition = Canvas.GetTop(player);

            foreach (Image obstacle in obstacles)
            {
                double obstacleX = Canvas.GetLeft(obstacle);
                double obstacleY = Canvas.GetTop(obstacle);

                if ((currentXPosition >= obstacleX && currentXPosition <= obstacleX + obstacle.Width) || (currentXPosition + obstacle.Width >= obstacleX && currentXPosition + obstacle.Width <= obstacleX + obstacle.Width))
                {

                    if ((currentYPosition >= obstacleY && currentYPosition <= obstacleY + obstacle.Height) || (currentYPosition + obstacle.Height >= obstacleY && currentYPosition + obstacle.Height <= obstacleY + obstacle.Height))
                    {

                        return true;
                    }
                }
            }

            return false;
        }
    }
}
