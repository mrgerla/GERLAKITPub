﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        bool CheckCollision(UIElement player, Rectangle obstacles)
        {
            double currentXPosition = Canvas.GetLeft(player);
            double currentYPosition = Canvas.GetTop(player);

            double obstacleX = Canvas.GetLeft(obstacles);
            double obstacleY = Canvas.GetTop(obstacles);


            if ((currentXPosition > obstacleX && currentXPosition < obstacleX + obstacles.Width) || (currentXPosition + obstacles.Width > obstacleX && currentXPosition + obstacles.Width < obstacleX + obstacles.Width))
            {

                if ((currentYPosition > obstacleY && currentYPosition < obstacleY + obstacles.Height) || (currentYPosition + obstacles.Height > obstacleY && currentYPosition + obstacles.Height < obstacleY + obstacles.Height))
                {

                    return true;
                }
            }

            return false;
        }




        bool CheckCollision(UIElement player, List<Rectangle> obstacles)
        {
            double currentXPosition = Canvas.GetLeft(player);
            double currentYPosition = Canvas.GetTop(player);

            foreach (Rectangle obstacle in obstacles)
            {
                double obstacleX = Canvas.GetLeft(obstacle);
                double obstacleY = Canvas.GetTop(obstacle);

                if ((currentXPosition > obstacleX && currentXPosition < obstacleX + obstacle.Width) || (currentXPosition + obstacle.Width > obstacleX && currentXPosition + obstacle.Width < obstacleX + obstacle.Width))
                {

                    if ((currentYPosition > obstacleY && currentYPosition < obstacleY + obstacle.Height) || (currentYPosition + obstacle.Height > obstacleY && currentYPosition + obstacle.Height < obstacleY + obstacle.Height))
                    {

                        return true;
                    }
                }
            }

            return false;
        }

        bool CheckCollision(UIElement player, List<Ellipse> obstacles)
        {
            double currentXPosition = Canvas.GetLeft(player);
            double currentYPosition = Canvas.GetTop(player);

            foreach (var obstacle in obstacles)
            {
                double obstacleX = Canvas.GetLeft(obstacle);
                double obstacleY = Canvas.GetTop(obstacle);

                if ((currentXPosition > obstacleX && currentXPosition < obstacleX + 50) || (currentXPosition + 50 > obstacleX && currentXPosition + 50 < obstacleX + 50))
                {
                    if ((currentYPosition > obstacleY && currentYPosition < obstacleY + 50) || (currentYPosition + 50 > obstacleY && currentYPosition + 50 < obstacleY + 50))
                    {
                        return true;
                    }
                }
            }

            return false;
        }


        bool CheckCollision(UIElement player, List<Image> obstacles)
        {
            double currentXPosition = Canvas.GetLeft(player);
            double currentYPosition = Canvas.GetTop(player);

            foreach (var obstacle in obstacles)
            {
                double obstacleX = Canvas.GetLeft(obstacle);
                double obstacleY = Canvas.GetTop(obstacle);

                if ((currentXPosition > obstacleX && currentXPosition < obstacleX + 50) || (currentXPosition + 50 > obstacleX && currentXPosition + 50 < obstacleX + 50))
                {
                    if ((currentYPosition > obstacleY && currentYPosition < obstacleY + 50) || (currentYPosition + 50 > obstacleY && currentYPosition + 50 < obstacleY + 50))
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}
