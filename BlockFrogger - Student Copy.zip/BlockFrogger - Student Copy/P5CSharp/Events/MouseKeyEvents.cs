﻿using System.Windows.Input;

namespace P5CSharp_Ver2
{
    public partial class Project
    {       
        //Mouse
        private double MouseX;
        private double MouseY;
        System.Reflection.MethodInfo? _mousePressedMethodInfo;

        //Key
        private Key key;
        System.Reflection.MethodInfo? _keyPressedMethodInfo;

        private void GetEventMethodInfo()
        {
            _mousePressedMethodInfo = typeof(Project).GetMethod("MousePressed");
            _keyPressedMethodInfo = typeof(Project).GetMethod("KeyPressed");
        }

        private void mousePressedSubscriber(object sender, MouseButtonEventArgs e)
        {
            MouseX = e.GetPosition(window).X;
            MouseY = e.GetPosition(window).Y;
            if (_mousePressedMethodInfo != null) _mousePressedMethodInfo.Invoke(this, null);
        }

        private void keyPressedSubscriber(object sender, KeyEventArgs e)
        {
            if (_keyPressedMethodInfo != null) _keyPressedMethodInfo.Invoke(this, null);
            key = e.Key;
        }

        /// <summary>
        /// Determines if a key is currently pressed.
        /// Will return true or false.
        /// </summary>
        /// <param name="key">Enter the key as Key.___</param>
        /// <returns></returns>
        private bool IsKeyDown(Key key)
        {
            if (Keyboard.IsKeyDown(key))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
