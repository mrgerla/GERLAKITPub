﻿using System.Windows.Shapes;

namespace P5CSharp_Ver2
{
    public partial class Project
    {

        /// <summary>
        /// Draws a straight line between two points. 
        /// Returns a Line.
        /// </summary>
        /// <param name="name">Name</param>
        /// <param name="point1X">Point 1's x coordinate</param>
        /// <param name="point1Y">Point 1's y coordinate</param>
        /// <param name="point2X">Point 2's x coordinate</param>
        /// <param name="point2Y">Point 2's y coordinate</param>
        /// <returns>A Line. Save to a variable to modify afterwards.</returns>
        public Line Line(double point1X, double point1Y, double point2X, double point2Y)
        {
            Line _line = new Line
            {
                
                X1 = point1X,
                Y1 = point1Y,
                X2 = point2X,
                Y2 = point2Y,
                Stroke = strokeColor,
                StrokeThickness = strokeWeight,
            };

            if (canvas != null) { canvas.Children.Add(_line); }
            return _line;
        }
    }
}
