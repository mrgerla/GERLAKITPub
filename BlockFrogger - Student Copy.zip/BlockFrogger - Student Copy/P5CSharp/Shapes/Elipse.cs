﻿using System.Windows.Controls;
using System.Windows.Shapes;

namespace P5CSharp_Ver2
{
    public partial class Project
    {


        //Returns an Ellipse
        /// <summary>
        /// Draws a circle on the canvas.
        /// If given 4 parameters will draw a circle.
        /// If given 5 parameters will draw an ellipse.
        /// </summary>
        /// <param name="name">Enter name in quotation Marks</param>
        /// <param name="xLocation">Set x Location of Middle of Circle</param>
        /// <param name="yLocation">Set y Location of Middle of Circle</param>
        /// <param name="radius">Set x Location of Middle of Circle</param>
        /// <returns>An Ellipse. Save to a variable to modify afterwards.</returns>
        public Ellipse Ellipse(double xLocation, double yLocation, double radius)
        {
            Ellipse newEllipse = new Ellipse
            {
                
                Width = radius,
                Height = radius,
                Fill = fillColor,
                Stroke = strokeColor,
                StrokeThickness = strokeWeight
            };
            newEllipse.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            newEllipse.VerticalAlignment = System.Windows.VerticalAlignment.Center;
            newEllipse.Visibility = System.Windows.Visibility.Visible;

            Canvas.SetLeft(newEllipse, xLocation);
            Canvas.SetTop(newEllipse, yLocation - radius);

            if (canvas != null)
            {
                canvas.Children.Add(newEllipse);
            }

            return newEllipse;

        }

        //Returns an Ellipse
        /// <summary>
        /// Draws a circle on the canvas.
        /// If given 4 parameters will draw a circle.
        /// If given 5 parameters will draw an ellipse.
        /// </summary>
        /// <param name="name">Enter name in quotation Marks</param>
        /// <param name="xLocation">Set x Location of Middle of Circle</param>
        /// <param name="yLocation">Set y Location of Middle of Circle</param>
        /// <param name="radius">Set x Location of Middle of Circle</param>
        /// <returns>An Ellipse. Save to a variable to modify afterwards.</returns>
        public Ellipse Ellipse(double xLocation, double yLocation, double xRadius, double yRadius)
        {
            Ellipse newEllipse = new Ellipse
            {
                Width = xRadius,
                Height = yRadius,
                Fill = fillColor,
                Stroke = strokeColor,
                StrokeThickness = strokeWeight

            };
            newEllipse.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            newEllipse.VerticalAlignment = System.Windows.VerticalAlignment.Center;
            newEllipse.Visibility = System.Windows.Visibility.Visible;

            Canvas.SetLeft(newEllipse, xLocation);
            Canvas.SetTop(newEllipse, yLocation - yRadius);
            if (canvas != null)
            {
                canvas.Children.Add(newEllipse);
            }

            return newEllipse;

        }
    }
}
