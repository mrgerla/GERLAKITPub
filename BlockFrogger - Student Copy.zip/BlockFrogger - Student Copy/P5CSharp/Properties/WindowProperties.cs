﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        /// <summary>
        /// Sets the size of the canvas.
        /// Enter a 3rd parameter as false to make it so screen size can be changed by user.
        /// </summary>
        /// <param name="width">Width of Canvas</param>
        /// <param name="height">Height of Canvas</param>
        /// <param name="lockScreenSize">Write as false to make it so you can resize image.</param>
        public void SetWindowSize(int width, int height, bool lockScreenSize = true)
        {
            if (lockScreenSize)
            {
                consoleLog.MaxWidth = width-15; //-15 This accounts for the scroll bars
                consoleLog.MinWidth = width-15;// -15 accounts for the scroll bars
                canvas.Width = width;
                canvas.Height = height;
                window.MaxHeight = height + 200;
                window.MaxHeight = height + 200;
                window.MaxWidth = width;
                window.MinWidth = width;
                


            }
            else
            {
                window.Height = height + 200;
                window.Width = width;
                consoleLog.Width=width;
                canvas.Width=width;
                canvas.Height=height;
            }
        }
    }
}
