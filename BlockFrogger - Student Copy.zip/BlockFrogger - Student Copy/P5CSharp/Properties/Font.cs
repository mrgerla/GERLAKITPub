﻿using System;
using System.Diagnostics;
using System.Windows.Media;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        private FontFamily _font = new FontFamily("Comic Sans MS");
        private int _textSize = 10;

        //There should be a better way

        /// <summary>
        /// Changes Font of text.
        /// /// </summary>
        /// <param name="fontName">Enter name of font in quotations.</param>
        //public void textFont(string fileName, string fontName)
        //{
            
        //    _font = new FontFamily(new Uri("pack://application:,,,/"), "./resources/#Alex Brush");
        //    Debug.WriteLine()
        //    //_font = new FontFamily(@"C:\Users\VR02\Desktop\P5CSharp Ver2 - feb 8th - Copy (2)\Fonts\#Sassy Frass");
        //}

        /// <summary>
        /// Changes Font of Text
        /// <param name="fontName"/>Enter name of font from list in folder </param>
        /// </summary>
        private void textFont(string fontName)
        {
            _font = new FontFamily(fontName);
        }

        //From IA
        //TextBlock textBlock = new TextBlock();
        //textBlock.FontFamily = new FontFamily(new Uri("pack://application:,,,/fonts/MyFont.ttf"), "MyFont");
        //In this example, the Uri argument uses the pack:// scheme, which specifies that the font file is stored in the application's resources. The application:,,, portion specifies the application's current working directory, and the rest of the path specifies the location of the font file relative to the working directory.

        /// <summary>
        /// Changes the size of Text.
        /// </summary>
        /// <param name="fontSize">Enter the size of the font.</param>
        public void TextSize(int fontSize)
        {
            _textSize = fontSize;
        }
    }
}
