﻿using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows;
using System.Windows.Controls;

namespace P5CSharp_Ver2
{
    public partial class Project
    {

        /// <summary>
        /// Rotates shape around center of Shape by default.
        /// Optionally, can control rotation point using 3rd and 4th parameter.
        /// </summary>
        /// <param name="shape">Variable of Shape you want to rotate.</param>
        /// <param name="degreeAmount">Number of degrees you want to rotate.</param>
        /// <param name="xRotationPoint">X coordinate of rotation point between 0 and 1.</param>
        /// <param name="yRotationPoint">Y coordinate of rotation point between 0 and 1.</param>
        public void Rotate(Rectangle shape, double degreeAmount, double xRotationPoint = 0.5, double yRotationPoint = 0.5)
        {
            RotateTransform rotationAmount = new RotateTransform(degreeAmount);
            shape.RenderTransformOrigin = new Point(xRotationPoint, yRotationPoint);
            shape.RenderTransform = rotationAmount;
        }

        /// <summary>
        /// Rotates shape around center of Shape by default.
        /// Optionally, can control rotation point using 3rd and 4th parameter.
        /// </summary>
        /// <param name="shape">Variable of Shape you want to rotate.</param>
        /// <param name="degreeAmount">Number of degrees you want to rotate.</param>
        /// <param name="xRotationPoint">X coordinate of rotation point between 0 and 1.</param>
        /// <param name="yRotationPoint">Y coordinate of rotation point between 0 and 1.</param>
        public static void Rotate(Polygon shape, double degreeAmount, double xRotationPoint = 0.5, double yRotationPoint = 0.5)
        {
            RotateTransform rotationAmount = new RotateTransform(degreeAmount);
            shape.RenderTransformOrigin = new Point(xRotationPoint, yRotationPoint);
            shape.RenderTransform = rotationAmount;
        }


        /// <summary>
        /// Rotates shape around center of Shape by default.
        /// Optionally, can control rotation point using 3rd and 4th parameter.
        /// </summary>
        /// <param name="shape">Variable of Shape you want to rotate.</param>
        /// <param name="degreeAmount">Number of degrees you want to rotate.</param>
        /// <param name="xRotationPoint">X coordinate of rotation point between 0 and 1.</param>
        /// <param name="yRotationPoint">Y coordinate of rotation point between 0 and 1.</param>
        public static void Rotate(Line shape, double degreeAmount, double xRotationPoint = 0.5, double yRotationPoint = 0.5)
        {
            RotateTransform rotationAmount = new RotateTransform(degreeAmount);
            shape.RenderTransformOrigin = new Point(xRotationPoint, yRotationPoint);
            shape.RenderTransform = rotationAmount;
        }


        /// <summary>
        /// Rotates shape around center of Shape by default.
        /// Optionally, can control rotation point using 3rd and 4th parameter.
        /// </summary>
        /// <param name="shape">Variable of Shape you want to rotate.</param>
        /// <param name="degreeAmount">Number of degrees you want to rotate.</param>
        /// <param name="xRotationPoint">X coordinate of rotation point between 0 and 1.</param>
        /// <param name="yRotationPoint">Y coordinate of rotation point between 0 and 1.</param>
        public static void Rotate(Ellipse shape, double degreeAmount, double xRotationPoint = 0.5, double yRotationPoint = 0.5)
        {
            RotateTransform rotationAmount = new RotateTransform(degreeAmount);
            shape.RenderTransformOrigin = new Point(xRotationPoint, yRotationPoint);
            shape.RenderTransform = rotationAmount;
        }


        /// <summary>
        /// Rotates shape around center of Shape by default.
        /// Optionally, can control rotation point using 3rd and 4th parameter.
        /// </summary>
        /// <param name="shape">Variable of Shape you want to rotate.</param>
        /// <param name="degreeAmount">Number of degrees you want to rotate.</param>
        /// <param name="xRotationPoint">X coordinate of rotation point between 0 and 1.</param>
        /// <param name="yRotationPoint">Y coordinate of rotation point between 0 and 1.</param>
        public static void Rotate(Label shape, double degreeAmount, double xRotationPoint = 0.5, double yRotationPoint = 0.5)
        {
            RotateTransform rotationAmount = new RotateTransform(degreeAmount);
            shape.RenderTransformOrigin = new Point(xRotationPoint, yRotationPoint);
            shape.RenderTransform = rotationAmount;
        }


        /// <summary>
        /// Rotates shape around center of Shape by default.
        /// Optionally, can control rotation point using 3rd and 4th parameter.
        /// </summary>
        /// <param name="shape">Variable of Shape you want to rotate.</param>
        /// <param name="degreeAmount">Number of degrees you want to rotate.</param>
        /// <param name="xRotationPoint">X coordinate of rotation point between 0 and 1.</param>
        /// <param name="yRotationPoint">Y coordinate of rotation point between 0 and 1.</param>
        public static void Rotate(Image shape, double degreeAmount, double xRotationPoint = 0.5, double yRotationPoint = 0.5)
        {
            RotateTransform rotationAmount = new RotateTransform(degreeAmount);
            shape.RenderTransformOrigin = new Point(xRotationPoint, yRotationPoint);
            shape.RenderTransform = rotationAmount;
        }
    }
}
