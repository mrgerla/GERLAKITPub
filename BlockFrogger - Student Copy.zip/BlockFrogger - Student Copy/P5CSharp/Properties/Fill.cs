﻿using System.Windows.Media;

namespace P5CSharp_Ver2
{
    public partial class Project
    {

        private SolidColorBrush _fill = Brushes.Black;
        private bool _transparencyFillChange = false; //This is stupid. There must be another way... It's creating a reference/binding to brush, so it was not working as intended


        private SolidColorBrush fillColor
        {
            set
            {
                _fill = value;
            }

            get
            {

                if (!_transparencyFillChange)
                {
                    SolidColorBrush tempBrush = new SolidColorBrush();
                    tempBrush.Color = Color.FromRgb(_fill.Color.R, _fill.Color.G, _fill.Color.B); //This returns the values, instead of creating references
                    return tempBrush;
                }
                else
                {
                    SolidColorBrush tempBrush = new SolidColorBrush();
                    tempBrush.Color = Color.FromArgb(_fill.Color.A, _fill.Color.R, _fill.Color.G, _fill.Color.B);
                    return tempBrush;
                }
            }
        }


        /// <summary>
        /// Changes the fill color of shapes drawn. 
        /// 1. Give One Value for GreyScale
        /// 2. Give 3 Values for RGB
        /// 3. Give 4 Values for Transparency
        /// </summary>
        /// <param name="greyScale">Enter a value from 0 to 255</param>
        public SolidColorBrush Fill(byte greyScale)
        {
            SolidColorBrush newBrush = new SolidColorBrush(); //The property is locked... So need to create a whole new brush...
            newBrush.Color = Color.FromRgb(greyScale, greyScale, greyScale);
            fillColor = newBrush;
            _transparencyFillChange = false;
            return newBrush;
        }

        /// <summary>
        /// Changes the fill color of shapes drawn. 
        /// 1. Give One Value for GreyScale
        /// 2. Give 3 Values for RGB
        /// 3. Give 4 Values for Transparency
        /// </summary>
        /// <param name="redColor">Enter a value from 0 to 255 for Red Value</param>
        /// <param name="greenColor">Enter a value from 0 to 255 for Green Value</param>
        /// <param name="blueColor">Enter a value from 0 to 255 for Blue Value</param>
        public SolidColorBrush Fill(byte redColor, byte greenColor, byte blueColor)
        {
            SolidColorBrush newBrush = new SolidColorBrush();
            newBrush.Color = Color.FromRgb(redColor, greenColor, blueColor);
            fillColor = newBrush;
            _transparencyFillChange = false;
            return newBrush;
        }

        /// <summary>
        /// 1. Give One Value for GreyScale
        /// 2. Give 3 Values for RGB
        /// 3. Give 4 Values for Transparency
        /// </summary>
        /// <param name="redColor">Enter a value from 0 to 255 for Red Value</param>
        /// <param name="greenColor">Enter a value from 0 to 255 for Green Value</param>
        /// <param name="blueColor">Enter a value from 0 to 255 for Blue Value</param>
        /// <param name="transparency">Enter a value from 0 to 255 for Transparency</param>
        public SolidColorBrush Fill(byte redColor, byte greenColor, byte blueColor, byte transparency)
        {
            SolidColorBrush newBrush = new SolidColorBrush();
            newBrush.Color = Color.FromArgb(transparency, redColor, greenColor, blueColor);
            fillColor = newBrush;
            _transparencyFillChange = true;
            return newBrush;
        }

    }
}
