﻿using System.Windows.Media;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        //Stroke Color Variables
        private SolidColorBrush _strokeColor = Brushes.Black;

        private SolidColorBrush strokeColor
        {
            set
            {
                _strokeColor = value;
            }

            get
            {
                SolidColorBrush tempBrush = new SolidColorBrush();
                tempBrush.Color = Color.FromRgb(_strokeColor.Color.R, _strokeColor.Color.G, _strokeColor.Color.B); //This returns the values, instead of creating references
                return tempBrush;

            }
        }

        /// <summary>
        /// Changes the color of the border of the shape.
        /// 1. Enter 1 numbers between 0-255 or greyscale.
        /// 2. Enter 3 numbers between 0-255 for rgb 
        /// </summary>
        /// <param name="greyScale">Enter a number between 0-255 for greyscale</param>
        private SolidColorBrush Stroke(byte greyScale)
        {
            SolidColorBrush newBrush = new SolidColorBrush();
            newBrush.Color = Color.FromRgb(greyScale, greyScale, greyScale);
            strokeColor = newBrush;
            return newBrush;
        }

        /// <summary>
        /// Changes the color of the border of the shape.
        /// 1. Enter 1 numbers between 0-255 or greyscale.
        /// 2. Enter 3 numbers between 0-255 for rgb 
        /// </summary>
        /// <param name="red">Enter a number between 0-255 for red color</param>
        /// <param name="green">Enter a number between 0-255 for green color</param>
        /// <param name="blue">Enter a number between 0-255 for blue color</param>
        private SolidColorBrush Stroke(byte red, byte green, byte blue)
        {
            SolidColorBrush newBrush = new SolidColorBrush();
            newBrush.Color = Color.FromRgb(red, green, blue);
            strokeColor = newBrush;
            return newBrush;
        }



        //Stroke Weight Variables
        private int _strokeWeight = 1;
        private int strokeWeight
        {
            set { _strokeWeight = value; }
            get
            {
                int currentWeight = _strokeWeight; //So that it is NOT a reference
                return currentWeight;
            }
        }

        /// <summary>
        /// Changes the thickness of the border of a shape.
        /// </summary>
        /// <param name="weight">Enter a number to determine how thick the border of the shape</param>
        private int StrokeWeight(int weight)
        {
            _strokeWeight = weight;
            return _strokeWeight;
        }

    }
}
