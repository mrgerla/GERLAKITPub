﻿using System;
using System.Windows.Media.Imaging;
using System.Windows;
using System.Windows.Controls;
using System.IO;

namespace P5CSharp_Ver2
{
    public partial class Project
    {

        /// <summary>
        /// Draws an Image on canvas.
        /// </summary>
        /// <param name="fileName">Write file name in "". Be sure it is in Images folder.</param>
        /// <param name="xCoordinate">Left x coordinate of image</param>
        /// <param name="yCoordinate">Top y coordinate of image</param>
        /// <param name="width">Size of image. Keeps Aspect Ratio.</param>
        /// <returns>An Image. Save to a variable to modify afterwards.</returns>
        public Image Image(string fileName, double xCoordinate, double yCoordinate, int width)
        {
            //Creates Image Element in XAML
            Image newImage = new Image();
            newImage.Width = width;

            newImage.Source = new BitmapImage(new Uri($"..\\..\\..\\Images\\{fileName}", UriKind.Relative));
            newImage.Visibility = Visibility.Visible;
            
            Canvas.SetLeft(newImage, xCoordinate);
            Canvas.SetTop(newImage, yCoordinate);
            if (canvas != null) { canvas.Children.Add(newImage); }
            return newImage;

        }



        public MediaElement GIF(string fileName, double xCoordinate, double yCoordinate, int width)
        {
            MediaElement element = new MediaElement();
            element.Width = width;
            element.Height = width;
            element.Source = new Uri($"..\\..\\..\\Images\\{fileName}", UriKind.Relative);
            
            ////element.MediaEnded += ReplayGIF;
            element.LoadedBehavior = MediaState.Manual;
            element.UnloadedBehavior = MediaState.Manual;

            //element.MediaEnded += ReplayGIF;



            element.Play();

            //element.Stretch = Stretch.Fill;

            if (canvas != null) { canvas.Children.Add(element); }
            return element;
        }

        //private void ReplayGIF(object sender, RoutedEventArgs e)
        //{
        //    myMediaElement.Position = TimeSpan.Zero;
        //    myMediaElement.Play();
        //}

        //void ReplayGIF(MediaElement sender, EventArgs e)
        //{
        //    sender.Position = TimeSpan.FromMilliseconds(1);
        //    sender.Play();
        //}

        //static void ReplayGIF(object sender, EventArgs e)
        //{

        //}
    }
}
