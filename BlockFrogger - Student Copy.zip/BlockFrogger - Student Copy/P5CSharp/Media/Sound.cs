﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        private void PlaySound(string fileName)
        {
            Uri soundUri = new Uri($"..\\..\\..\\Sounds\\{fileName}", UriKind.Relative);
            SoundPlayer player = new SoundPlayer(soundUri.ToString());
            player.PlaySync();
        }

        private void PlayLoop(string fileName)
        {
            Uri soundUri = new Uri($"..\\..\\..\\Sounds\\{fileName}", UriKind.Relative);
            SoundPlayer player = new SoundPlayer(soundUri.ToString());
            player.PlayLooping();
        }
    }
}
