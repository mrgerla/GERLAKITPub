﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        //private void FadeAnimation(FrameworkElement shape, double seconds)
        //{
        //    var doubleAnimation = new DoubleAnimation();
        //    doubleAnimation.From = shape.Opacity;
        //    double newOpacity;
        //    if(shape.Opacity > 0.5)
        //    {
        //        newOpacity = 0.0;
        //    }
        //    else
        //    {
        //        newOpacity = 1.0;
        //    }
        //    doubleAnimation.To = newOpacity;
        //    doubleAnimation.Duration = new System.Windows.Duration(TimeSpan.FromSeconds(seconds));
        //    storyboard.Children.Add(doubleAnimation);

        //    Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath(FrameworkElement.OpacityProperty));

        //    storyboard.Begin(shape);
        //}

    }
}
