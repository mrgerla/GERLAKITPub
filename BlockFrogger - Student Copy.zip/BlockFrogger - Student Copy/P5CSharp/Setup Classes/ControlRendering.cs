﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P5CSharp_Ver2.P5CSharp.Setup_Classes
{
    internal class GetMethods
    {
    }
}
