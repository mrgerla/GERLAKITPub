﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Shapes;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        //Area for Variables to Store Costumes, Locations ect.
        
        //READ: carObstacles   is the variable that holds ALL of the car pictures. Use it for checking the collisions
        
        Rectangle player;

        

        public void Setup()
        {
            SetWindowSize(600, 600); //DO NOT CHANGE OR DELETE
            Background(150);
            CreateObstacles(); //DO NOT DELETE OR CHANGE


            //Player Code Area
            
            


        }//END of SETUP

        public void Update()
        {
                UpdateObstacles(); // DO NOT DELETE OR CHANGE
                
                

            

        }//END OF UPDATE




    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
