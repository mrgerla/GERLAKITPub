﻿using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.Collections.Generic;

namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Area for Player Variables
        
        //Random Numbers
        int num1;
        int num2;
        int answer;

        //Text on Screen
        Text instructions = Text("Answer the questions", 20, 50);
        Text question = Text("What is 1 + 4?", 20, 200);
        Text answerWriting = Text("Your answer is ", 20, 300);


        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(1000, 600);
            Background(100);

            //Random Number Set-Up
            num1 = random.Next(1, 5);
            num2 = random.Next(1, 5);

            //Text Set-Up
            instructions.Size = 40;
            question.Size = 35;
            question.Content = "What is " + num1 + " + " + num2 + "?";
            answerWriting.Size = 30;

        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update
            question.Content = "What is " + num1 + " + " + num2 + "?";
            answerWriting.Content = "You answer is " + KeyValue;

        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void KeyPressed()
        {
            if(answer == KeyValue)
            {
                
            }

            

        }



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
