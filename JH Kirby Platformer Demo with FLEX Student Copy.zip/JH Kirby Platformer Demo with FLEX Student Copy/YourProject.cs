﻿using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.Windows;
using System.Threading;

namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Area for Player Variables       
        
        #region Coded in Class - Block Set-Up and Kirby Set-Up
        //Blocks and Floor (Pre-Done for Speed of Demo)
        Image floor = Image("floor.png", 0, 500, 1000, 50);
        Image block1 = Image("starBlocks.png", 0, 300, 250, 50);
        Image block2 = Image("starBlocks.png", 400, 150, 250, 50);

        //Kirby Picture - Pre-Done for Speed of Demo
        Image kirby = Image("kirbyidle.png", 450, 400, 75, 75);
        int fallSpeed = 0;

        #endregion





        //All of you Shapes should be created here
        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(1000, 600);
            Background("background.jpg"); //Pre-Done



        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update
         
            //Gravity
            fallSpeed += 1;



            
            #region Coded in Class Kirby - Level 1 Collisions


                //Contacting a floor
                if (CheckCollision(kirby, floor))
                {
                    fallSpeed = 0;
                    SetYTo(kirby, 425); // // If someone complains that Kirby falls beneath a floor...
                }



                ///////////2nd Day/////////////
                ///            //Contact with Other Blocks
                //Contacting Left Block
                if (CheckCollision(kirby, block1))
                {
                    fallSpeed = 0;
                    SetYTo(kirby, 225); // // If someone complains that Kirby falls beneath a floor...


                }

                //Contacting Middle Block
                if (CheckCollision(kirby, block2))
                {
                    fallSpeed = 0;
                    SetYTo(kirby, 75); // // If someone complains that Kirby falls beneath a floor...


                }




                #endregion

                



            #region Coded in Class - Animations
            //Animations - I prioritized jumping for looks sake
            if (IsKeyDown(Key.Space))
            {
                kirby.Animate(0.2, "kirbyfly.png", "kirbyfly.png");
            }

            else if (IsKeyDown(Key.Right))
            {
                kirby.Animate(.5, "kirbyR1.png", "kirbyR2.png", "kirbyR3.png");
            }

            else if (IsKeyDown(Key.Left))
            {
                kirby.Animate(0.5, "kirbyL1.png", "kirbyL2.png", "kirbyL3.png");
            }

            else
            {
                kirby.Animate(0.1, "kirbyidle.png", "kirbyidle.png");
            }

            #endregion

            #region Coded in Class Kirby Moving
            //Update Kirby



            //Jumping - Note that it is done after check for the ground, or ground will make 0 after.
            //Kirby... Floats so we can double jump
            if (IsKeyDown(Key.Space))
            {
                fallSpeed -= 3;

                // // If someone complains that kiby goes too high too fast...
                if (fallSpeed < -10)
                {
                    fallSpeed = -10;
                }


            }


            kirby.Y += fallSpeed;



            //Pre-Done Code to make Kirby move right and left
            if (IsKeyDown(Key.Right))
            {
                kirby.X += 5;
            }

            if (IsKeyDown(Key.Left))
            {
                kirby.X -= 5;
            }


            #endregion


        }//END OF UPDATE



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
