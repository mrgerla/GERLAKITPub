﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.IO;
using System.Collections.Generic;
using System;

#endregion


namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(500, 400);
            Background(0,0,0);

            //Rectangle Drawing
            




            //Circle Drawing
            




            //Line
            




        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update
            






        }//END OF UPDATE




    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
