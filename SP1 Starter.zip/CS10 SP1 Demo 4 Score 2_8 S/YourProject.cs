﻿#region ToolKits
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.IO;
using System.Collections.Generic;
using System;


#endregion


namespace SPARKProject
{
   

    public partial class Project
    {//DO NOT DELETE
 

        //Create Global Variables




        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(600, 600); 
            Background(100);

            //Draw Circles on Screen
            MovingCircles.create(10);

            //Change Text Color/Size
            






        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update

            MovingCircles.moveAllCircles();
            
            

        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            //No matter what increase attempts
            




            //Check if circle clicked
            if (MovingCircles.CircleClicked())
            {
                

            }//end of Circle Clicked Code


            //Calculate Rate

            



        } // End of Mouse Pressed



        public void KeyPressed()
        {
            //Reset








        } // End of Keypressed

        



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
