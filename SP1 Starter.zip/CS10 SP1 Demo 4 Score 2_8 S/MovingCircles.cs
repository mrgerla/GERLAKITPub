﻿using P5CSharp_Ver2;
using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using static P5CSharp_Ver2.GerlaKit;

namespace SPARKProject
{
    public class MovingCircles:Ellipse
    {
      
        int xSpeed;
        int ySpeed;
        int RandXDirection;
        int RandYDirection;
        int XMovementDirection = 1;
        int YMovementDirection = 1;
        static Random rand= new Random();
        
        static List<MovingCircles> allCircles = new List<MovingCircles>();

        MovingCircles(int X, int Y, int Radius):base(X, Y,Radius,Radius){

            xSpeed= rand.Next(1, 5);
            ySpeed = rand.Next(1, 5);

            RandXDirection = rand.Next(0, 2);
            RandYDirection = rand.Next(0, 2);
            
            if (RandXDirection == 0)
            {
                XMovementDirection = -1;
            }

            if (RandYDirection == 0)
            {
                YMovementDirection = -1;
            }

            Brush color = Fill((byte)random.Next(0, 255), (byte)random.Next(0, 255), (byte)random.Next(0, 255));
            Fill = color;
            Stroke = color;
        }//end of constructor

        //Create Circles
        public static void create(int num)
        {
            int Radius = rand.Next(10, 50);
            int XLocation = rand.Next(50, 550);
            int YLocation = rand.Next(50, 550);    


            if (allCircles.Count < num)
            {
                allCircles.Add(new MovingCircles(XLocation, YLocation, Radius));

                create(num);
            }
        }

        public static void moveAllCircles()
        {
            foreach(var circle in allCircles)
            {
                circle.X += circle.xSpeed * circle.XMovementDirection;
                circle.Y += circle.ySpeed * circle.YMovementDirection;

                if (circle.X < 0 - circle.Width)
                {
                    circle.X = 600 + circle.Width;
                }
                else if (circle.X > 600 + circle.Width)
                {
                    circle.X = -circle.Width;
                }

                if (circle.Y < 0 - circle.Height)
                {
                    circle.Y = 600+circle.Height;
                }
                else if (circle.Y > 600 + circle.Height)
                {
                    circle.Y = 0 - circle.Height;
                }
            }
        }

        public static bool CircleClicked()
        {
            List<int> indexOfClicked= new List<int>();
            int i =0;
            bool circleClicked = false;
            
            //Check if circle clicked, if yes, add it to List
            foreach(var circle in allCircles)
            {

                if (MouseOver(circle))
                {
                    indexOfClicked.Insert(0, i); //Need to go backwards so that we aren't changing the index before deleting if multiple circles
                    circleClicked= true;
                    
                }
                i++;


            }

            int startingNumCircles = allCircles.Count;

            
            //Delete Circle
            foreach (int index in indexOfClicked)
            {
                canvas.Children.Remove(allCircles[index]);
                allCircles.Remove(allCircles[index]);             
            }
            
            //Create new circles
            create(startingNumCircles);

            //So students can use in if statement
            if (circleClicked)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }



    }
}
