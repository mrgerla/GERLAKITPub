﻿using System;
using System.Collections.Generic;
using System.Windows.Shapes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;

namespace SPARKProject
{
    public partial class Project
    {
        List<Image>? obstacles = new List<Image>();
        Image obstacle1;
        Image obstacle2;
        Image obstacle3;
        Image obstacle4;
        Image obstacle5;
        Image obstacle6;
        Image obstacle7;
        Image obstacle8;
        Image obstacle9;
        Image obstacle10;
        Image obstacle11;
        Image obstacle12;



        void CreateObstacles(string imageName)
        {
            obstacle1 = Image(imageName, 0, 100, 70, 50);
            obstacle2 = Image(imageName, 150, 100, 70, 50);
            obstacle3 = Image(imageName, 300, 100, 70, 50);
            obstacle4 = Image(imageName, 450, 100, 70, 50);
            obstacle5 = Image(imageName, 50, 250, 70, 50);
            obstacle6 = Image(imageName, 200, 250, 70, 50);
            obstacle7 = Image(imageName, 350, 250, 70, 50);
            obstacle8 = Image(imageName, 500, 250, 70, 50);
            obstacle9 = Image(imageName, 0, 400, 70, 50);
            obstacle10 = Image(imageName, 150, 400, 70, 50);
            obstacle11 = Image(imageName, 300, 400, 70, 50);
            obstacle12 = Image(imageName, 450, 400, 70, 50);

            obstacles.Add(obstacle1);
            obstacles.Add(obstacle2);
            obstacles.Add(obstacle3);
            obstacles.Add(obstacle4);
            obstacles.Add(obstacle5);
            obstacles.Add(obstacle6);
            obstacles.Add(obstacle7);
            obstacles.Add(obstacle8);
            obstacles.Add(obstacle9);
            obstacles.Add(obstacle10);
            obstacles.Add(obstacle11);
            obstacles.Add(obstacle12);



        }

        void UpdateObstacles(int speed)
        {
            for (int i = 0; i < obstacles.Count; i++)
            {
                ChangeXBy(obstacles[i], speed);

                double currentLocation = obstacles[i].X;
                if (currentLocation > 550) {
                    SetXTo(obstacles[i], -40);                
                
                }
                
                
                

            }

        }



    }
}
