﻿using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;
using System.Collections.Generic;

namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Area for Player Variables
        Image player = new Image("indy.png", 40, 250, 150, 150);

        //Enemies
        List<Image> enemy = new List<Image>();
        List<string> names = new List<string> { "Mummy", "Snake Charmer", "Anubis"};
        List<int> coins = new List<int> { 5, 3, 10 };
        List<string> abilities = new List<string> { "rap", "snakes", "magic" };


        //Screen Text
        Rectangle textBox = new Rectangle(0, 450, 1000, 200);
        Text dialogBox = new Text("Beware Traveler of the Dangers Lurking in the Ruins", 20, 500);

        //Challenge solution///////////////////////
        int enemyIndex;

        //All of you Shapes should be created here
        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(1000, 600);
            Background("egypt.webp");
            enemy.Add(new Image("Mummy.png", 700, 300, 150, 150));
            enemy.Add(new Image("snakeCharmer.png", 700, 300, 150, 150));
            enemy.Add(new Image("anubis.png", 700, 300, 150, 150));

            //Hide All Enemies
            for(int i = 0; i <enemy.Count; i++)
            {
                enemy[i].Visibility = Hidden;
            }

            dialogBox.Color = Fill(255, 255, 255);
            dialogBox.Size = 30;


            //Challenge Solution//////////////////////////////
            int enemyIndex = random.Next(enemy.Count);

        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update
            if (IsKeyDown(Key.D))
            {
                player.X += 10;

            }
            if (IsKeyDown(Key.A))
            {
                player.X -= 10;

            }
            if (IsKeyDown(Key.W))
            {
                player.Y -= 10;

            }
            if (IsKeyDown(Key.S))
            {
                player.Y += 10;

            }

            ////Boundary Line
            //if (player.X > 300)
            //{
            //    enemy[2].Visibility = Visible;
            //    dialogBox.Content = $"{names[2]} has appeared with {coins[2]}!\nIt will terrify you with it's {abilities[2]}";
            //}

            //Challenge
            //Make it a random enemy
            if (player.X > 300)
            {
                enemy[enemyIndex].Visibility = Visible;
                dialogBox.Content = $"{names[enemyIndex]} has appeared with {coins[enemyIndex]}!\nIt will terrify you with it's {abilities[enemyIndex]}";
            }

        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            

            

        }



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
