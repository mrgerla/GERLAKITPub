﻿using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;

namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Area for Player Variables

        //Blocks and Floor (Pre-Done for Speed of Demo)
        Image floor = Image("floor.png", 0, 500, 1000, 50);
        Image block1 = Image("starBlocks.png", 0, 300, 250, 50);
        Image block2 = Image("starBlocks.png", 400, 150, 250, 50);

        //Kirby Picture - Pre-Done for Speed of Demo
        Image kirby = Image("kirbyidle.png", 450, 400, 75, 75);


        

        //All of you Shapes should be created here
        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(1000, 600);
            Background("background.jpg"); //Pre-Done


        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update


            




            //Pre-Done Code to make Kirby move right and left
            if (IsKeyDown(Key.Right))
            {
                kirby.X += 5;
            }

            if (IsKeyDown(Key.Left))
            {
                kirby.X -= 5;
            }





        }//END OF UPDATE


        //Runs once every time the mouse is clicked
        public void MousePressed()
        {
            

            

        }



    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
