﻿using System;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        /// <summary>
        /// Changes the COLOR of the Background.
        /// 1. Give one value for GREYSCALE
        /// 2. Give three values for RGB
        /// 3. Enter File Name for Image Background
        /// </summary>
        /// <param name="greyScale"></param>
        public void Background(object greyScale)
        {
            SolidColorBrush newBrush = new SolidColorBrush();
            newBrush.Color = Color.FromRgb(Convert.ToByte(greyScale), Convert.ToByte(greyScale), Convert.ToByte(greyScale));
            canvas.Background = newBrush;
        }


        /// <summary>
        /// Changes the COLOR of the Background.
        /// 1. Give one value for GREYSCALE
        /// 2. Give three values for RGB
        /// 3. Enter File Name for Image Background
        /// </summary>
        /// <param name="redColor"></param>
        /// <param name="greenColor"></param>
        /// <param name="blueColor"></param>
        public static void Background(object redColor, object greenColor, object blueColor)
        {
            SolidColorBrush newBrush = new SolidColorBrush();
            newBrush.Color = Color.FromRgb(Convert.ToByte(redColor), Convert.ToByte(greenColor), Convert.ToByte(blueColor));
            canvas.Background = newBrush;
        }


        /// <summary>
        /// Changes the COLOR of the Background.
        /// 1. Give one value for GREYSCALE
        /// 2. Give three values for RGB
        /// 3. Enter File Name for Image Background
        /// </summary>
        /// <param name="redColor"></param>
        /// <param name="greenColor"></param>
        /// <param name="blueColor"></param>
        public void Background(string fileName)
        {
            ImageBrush newImage = new ImageBrush();
            newImage.Stretch = Stretch.Fill;
            newImage.ImageSource = new BitmapImage(new Uri($"..\\..\\..\\Images\\{fileName}", UriKind.Relative));
            canvas.Background = newImage;
        }
    }
}
