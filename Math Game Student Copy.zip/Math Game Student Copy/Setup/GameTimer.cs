﻿using System;
using System.Diagnostics;
using System.Windows.Threading;
using static P5CSharp_Ver2.GerlaKit;

namespace SPARKProject
{
    

    public partial class MainWindow
    {
        private Stopwatch programRunTime = Stopwatch.StartNew();
        public static int FrameRate = 60;

        /// <summary>
        /// Sets up a timer to run update loop.
        /// </summary>
        private void SetupGameTimer()
        {
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(1000 / FrameRate);
            timer.Tick += UpdateData;
            timer.Start();
        }

        private void UpdateData(object? sender, EventArgs e)
            {
                if(_projectUpdateMethod != null) _projectUpdateMethod.Invoke(project, null);
                UpdateDeltaTime(programRunTime.ElapsedMilliseconds);
               
            }

    }
}

//This is supposed to start a new thread. It is not working, so... for now use the same thread as the UI
//private void setupGameTimer()
//{
//    Task.Factory.StartNew(() =>
//    {
//        DispatcherTimer timer = new DispatcherTimer();
//        timer.Interval = TimeSpan.FromMilliseconds(1000 / 60);
//        timer.Tick += updateData;
//        timer.Start();

//    });
//}
