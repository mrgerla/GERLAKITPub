﻿using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static System.Windows.Visibility;
using static P5CSharp_Ver2.GerlaKit;

namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE

        //Area for Player Variables


        //All of you Shapes should be created here
        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(600, 600);
            Background(150);




        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update



        }//END OF UPDATE


  

        //Methods can go below this comment





    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
