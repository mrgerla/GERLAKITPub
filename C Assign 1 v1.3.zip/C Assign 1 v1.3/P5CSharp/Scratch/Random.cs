﻿namespace P5CSharp_Ver2
{
    public partial class Project
    {
        /// <summary>
        /// Creates a random number.
        /// </summary>
        /// <param name="min">Enter lowest number.</param>
        /// <param name="max">Enter highest number.</param>
        private int RandomNumber(int min, int max)
        {
            return random.Next(min, max+1);
        }
        

        
    }
}
