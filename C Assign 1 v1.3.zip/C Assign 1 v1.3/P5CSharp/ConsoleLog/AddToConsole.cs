﻿using System.Windows.Input;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        /// <summary>
        /// Prints content to Console.
        /// </summary>
        /// <param name="content">Enter information to be printed</param>
        private void Print(object content)
        {
            object currentContent = consoleContent.Content;
            consoleContent.Content = content + "\n" + currentContent;
        }

        /// <summary>
        /// Prints Mouse Location to Console.
        /// </summary>
        private void PrintMouseLocation()
        {
            var mouseLocation = Mouse.GetPosition(canvas);
            Print("X: " + mouseLocation.X + ", Y: " + mouseLocation.Y);
        }

    }
}
