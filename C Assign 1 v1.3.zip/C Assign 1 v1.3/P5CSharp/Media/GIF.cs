﻿using System;
using System.Windows.Media.Imaging;
using System.Windows;
using System.Windows.Controls;
using System.IO;
using System.Collections.Generic;
using P5CSharp_Ver2.P5CSharp.Setup_Classes;
using System.Diagnostics;
using System.Windows.Media;

namespace P5CSharp_Ver2
{
    internal class GIF: FrameworkElement
    {
        List<BitmapImage> frames = new List<BitmapImage>();

        private int frameRateCounter = 0;
        private int frameRate = 60; // Number of frames to display per second
        private double lastRenderTime = 0;
        private int currentFrame = 0;

        public GIF(string fileName, int xLocation, int yLocation, int width, int height, int testframe)
        {
            
            
            //Break GIF into PNG pics
            using(FileStream stream = new FileStream(@"C:\Users\gerla\Downloads\BlockFrogger - Answer Key\BlockFrogger - Answer Key\Images\gif2.gif", FileMode.Open)){
                BitmapDecoder decoder = new GifBitmapDecoder(stream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);

                for(int i = 0; i < decoder.Frames.Count; i++)
                {
                    BitmapFrame frame = decoder.Frames[i];

                    // Create a BitmapImage from the current frame
                    BitmapImage image = new BitmapImage();
                    image.BeginInit();
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.StreamSource = new MemoryStream();
                    BitmapEncoder encoder = new BmpBitmapEncoder();
                    encoder.Frames.Add(frame);
                    encoder.Save(image.StreamSource);
                    image.StreamSource.Seek(0, SeekOrigin.Begin);
                    image.EndInit();


                    frames.Add(image);
                }
            }

            Width = width;
            Height = height;
            Canvas.SetLeft(this, xLocation);
            Canvas.SetTop(this, yLocation);

            CompositionTarget.Rendering += CompositionTarget_Rendering;

            Project.canvas.Children.Add (this);
                

        }//end of constructor


        private void CompositionTarget_Rendering(object sender, EventArgs e)
        {
            double currentTime = ((RenderingEventArgs)e).RenderingTime.TotalMilliseconds;
            double elapsed = currentTime - lastRenderTime;
            if (elapsed < 1000.0 / frameRate) // Limit the frame rate
            {
                return;
            }

            lastRenderTime = currentTime;

            frameRateCounter++;
            if (frameRateCounter % frameRate == 0)
            {
                currentFrame++;
                if (currentFrame >= frames.Count)
                {
                    currentFrame = 0;
                }
                InvalidateVisual();
            }
        }

        protected override void OnRender(DrawingContext drawingContext)
        {
            if (frames.Count > 0)
            {
                drawingContext.DrawImage(frames[currentFrame], new Rect(0, 0, Width, Height));
            }
        }


    }
}
