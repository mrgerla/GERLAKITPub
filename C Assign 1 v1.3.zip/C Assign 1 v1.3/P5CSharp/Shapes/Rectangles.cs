﻿using System.Windows.Shapes;
using System.Windows.Controls;

namespace P5CSharp_Ver2
{
    public partial class Project
    {
        /// <summary>
        /// Draws a rectangle on the screen.
        /// </summary>
        /// <param name="xLocation">x location of rectangle</param>
        /// <param name="yLocation">y location of rectangle</param>
        /// <param name="width">width of rectangle</param>
        /// <param name="height">height of rectangle</param>
        /// <returns></returns>
        private Rectangle Rect(double xLocation, double yLocation, double width, double height = 0)
        {
            if(height == 0) { height = width; }
            Rectangle newRectangle = new Rectangle
            {
                
                Width = width,
                Height = height,
                Fill = fillColor,
                Stroke = strokeColor,
                StrokeThickness = strokeWeight,

            };

            Canvas.SetLeft(newRectangle, xLocation);
            Canvas.SetTop(newRectangle, yLocation);

            if (canvas != null)
            {
                canvas.Children.Add(newRectangle);
            }

            return newRectangle;

        }



    }
}
