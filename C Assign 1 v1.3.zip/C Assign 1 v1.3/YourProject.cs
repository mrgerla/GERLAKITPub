﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Shapes;

namespace P5CSharp_Ver2
{
    public partial class Project
    {//DO NOT DELETE

        //Area for Player Variables

        
        


        //All of you Shapes should be created here
        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(600, 600); //For this assignment, do not change
            Background(150);
            CreateObstacles("gandalf.png"); //Enter Image Name


        }//END of SETUP

        //Makes the following changes 30 times per second
        public void Update()
        {//Start of Update
            UpdateObstacles(5);//Do not change. GERLA Custom Code for this asssignment only



        }//END OF UPDATE


        //Methods can go below this comment





    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
