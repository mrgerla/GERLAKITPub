﻿using P5CSharp_Ver2;
using System.Diagnostics;
using System.Windows.Input;
using static P5CSharp_Ver2.GerlaKit;

namespace SPARKProject
{
    public partial class Project
    {//DO NOT DELETE
        
        //Area for Player Variables
        Ball ballInfo;
        Ellipse ball;
        string BallOut = "";





        //All of you Shapes should be created here
        //Runs once at the start
        public void Setup()
        {//Start of Setup
            SetWindowSize(600, 600);
            Background(150);
            
            //Setting-up Ball. DO NOT CHANGE
            ballInfo = new Ball(window, 300, 300, 40, 5);
            ball = Ellipse(ballInfo.x, ballInfo.y, ballInfo.radius, ballInfo.radius);
            
            //END of Setup



        }//END of SETUP


        //Makes the following changes 60 times per second
        public void Update()
        {//Start of Update
            //Making Ball Move
            ballInfo.Update();
            ball.X = ballInfo.pos.X;
            ball.Y = ballInfo.pos.Y;
            BallOut = ballInfo.OutOfBounds();
            //End of making ball move


            //Determining if Ball hit paddle
            //You need to add the information as follows
            //( paddle1x,   paddle1Y ,  paddle2X,  paddle2Y,  widthOfPaddle,  heightOfPaddle)
            //Note: your variable names may be different

            //ballInfo.Hit();




        }//END OF UPDATE


        //Methods can go below this comment





    }//DO NOT DELETE! DO NOT PUT CODE AFTER THIS
}//DO NOTE DELETE! DO NOT PUT CODE AFTER THIS
