﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_6___Pokemon
{
    internal class Program
    {
        //Random - Outside of main so it can accessed in any methods
        static Random rand = new Random();

        static void Main(string[] args)
        {
            //Console Set-Up
            Console.BackgroundColor = ConsoleColor.DarkYellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();

            // Initial HP for both Pokémon
            int pikachuHp = 100;
            int squirtleHp = 100;

            Console.WriteLine("A wild squirtle appears!\n");
            Console.WriteLine(@"               _,........__
            ,-'            ""`-.
          ,'                   `-.
        ,'                        \
      ,'                           .
      .'\               ,"""".       `
     ._.'|             / |  `       \
     |   |            `-.'  ||       `.
     |   |            '-._,'||       | \
     .`.,'             `..,'.'       , |`-.
     l                       .'`.  _/  |   `.
     `-.._'-   ,          _ _'   -"" \  .     `
`.""""""""""'-.`-...,---------','         `. `....__.
.'        `""-..___      __,'\          \  \     \
\_ .          |   `""""""""'    `.           . \     \
  `.          |              `.          |  .     L
    `.        |`--...________.'.        j   |     |
      `._    .'      |          `.     .|   ,     |
         `--,\       .            `7""""' |  ,      |
            ` `      `            /     |  |      |    _,-'""""""`-.
             \ `.     .          /      |  '      |  ,'          `.
              \  v.__  .        '       .   \    /| /              \
               \/    `""""\""""""""""""""`.       \   \  /.''                |
                `        .        `._ ___,j.  `/ .-       ,---.     |
                ,`-.      \         .""     `.  |/        j     `    |
               /    `.     \       /         \ /         |     /    j
              |       `-.   7-.._ .          |""          '         /
              |          `./_    `|          |            .     _,'
              `.           / `----|          |-............`---'
                \          \      |          |
               ,'           )     `.         |
                7____,,..--'      /          |
                                  `---.__,--.'mh");

            Console.WriteLine("\n\n\n\n");

            // Loop until one of them loses all HP
            while (pikachuHp > 0 && squirtleHp > 0)
            {

                Console.WriteLine("Choose Pikachu's move: 1) Thundershock 2) Tackle");
                string moveChoice = Console.ReadLine();
                int damage = 0;

                if (moveChoice == "1")
                {
                    // Thundershock (super effective against Squirtle)


                    Console.WriteLine($"Pikachu uses Thundershock and does {damage} damage!");
                }
                else
                {
                    // Tackle (not super effective)


                    Console.WriteLine($"Pikachu uses Tackle and does {damage} damage!");
                }

                // Subtract damage from Squirtle's HP
                squirtleHp -= damage;

                if (squirtleHp <= 0)
                {
                    Console.WriteLine("Squirtle fainted! Pikachu wins!");
                    break;
                }

                // Squirtle's attack (e.g., Water Gun)
                int squirtleDamage = 0;
                Console.WriteLine($"Squirtle uses Water Gun and does {squirtleDamage} damage!");

                // Subtract damage from Pikachu's HP
                pikachuHp -= squirtleDamage;

                if (pikachuHp <= 0)
                {
                    Console.WriteLine("Pikachu fainted! Squirtle wins!");
                }

                // Show remaining HP
                Console.WriteLine($"Pikachu HP: {pikachuHp}");
                Console.WriteLine($"Squirtle HP: {squirtleHp}");
            }
        }

    }
}
